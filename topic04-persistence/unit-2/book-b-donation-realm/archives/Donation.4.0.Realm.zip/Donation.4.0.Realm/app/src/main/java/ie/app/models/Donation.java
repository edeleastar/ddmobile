package ie.app.models;

import java.util.UUID;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Donation extends RealmObject
{
    @PrimaryKey
    public String id;
    public int    amount;
    public String method;

    public Donation() {}

    public Donation (int amount, String method)
    {
        this.id = UUID.randomUUID().toString();
        this.amount = amount;
        this.method = method;
    }

    @Override
    public String toString() {
        return "Donation{" +
                "id = " + id +
                "amount=$" + amount +
                ", method='" + method + '\'' +
                '}';
    }
}

