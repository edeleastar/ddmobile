package ie.app.activities;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

import ie.app.R;
import ie.app.main.DonationApp;
import ie.app.models.Donation;

public class Report extends Base implements OnItemClickListener
{
    ListView listView;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        listView = findViewById(R.id.reportList);
        DonationAdapter adapter = new DonationAdapter(this,  app.dbManager.getAll(), app);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> arg0, View arg1, int pos, long id) {

        Toast.makeText(this, "You Selected Row [ " + pos + "]\n" +
                "For Donation Data [ " + app.dbManager.get(arg1.getTag().toString()) + "]\n " +
                "With ID of [" + id + "]", Toast.LENGTH_LONG).show();

    }
}

class DonationAdapter extends ArrayAdapter<Donation>
{
    public Context context;
    public List<Donation> donations;
    public DonationApp app;

    public DonationAdapter(Context context, List<Donation> donations, DonationApp app)
    {
        super(context, R.layout.row_donate, donations);
        this.context   = context;
        this.donations = donations;
        this.app = app;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        final View     view       = inflater.inflate(R.layout.row_donate, parent, false);
        Donation donation   = donations.get(position);
        TextView amountView = view.findViewById(R.id.row_amount);
        TextView methodView = view.findViewById(R.id.row_method);
        ImageView deleteView = view.findViewById(R.id.imageDelete);

        amountView.setText("$" + donation.amount);
        methodView.setText(donation.method);

        view.setTag(donation.id);

        deleteView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context, "You Want to Delete Donation " +
                        "[ " + app.dbManager.get(view.getTag().toString()) + "]",Toast.LENGTH_LONG).show();

            }
        });

        return view;
    }

    @Override
    public int getCount()
    {
        return donations.size();
    }
}