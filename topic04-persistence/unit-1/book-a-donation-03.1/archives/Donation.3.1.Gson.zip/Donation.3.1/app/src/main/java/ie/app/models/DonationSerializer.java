package ie.app.models;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import android.content.Context;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class DonationSerializer
{
    private Context mContext;
    private String mFilename;
    private int totalDonated;

    Type objType = new TypeToken<List<Donation>>(){}.getType();

    public DonationSerializer(Context c, String f)
    {
        mContext = c;
        mFilename = f;
    }

    public void saveDonations(List<Donation> donations) throws JSONException, IOException
    {
        String result = new Gson().toJson(donations, objType);
        Writer writer = null;
        try
        {
            OutputStream out = mContext.openFileOutput(mFilename, Context.MODE_PRIVATE);
            writer = new OutputStreamWriter(out);
            writer.write(result);
        }
        finally
        {
            if (writer != null)
                writer.close();
        }
    }

    public ArrayList<Donation> loadDonations() throws IOException, JSONException
    {
        ArrayList<Donation> donations = new ArrayList<Donation>();
        BufferedReader reader = null;
        totalDonated = 0;

        try
        {
            InputStream in = mContext.openFileInput(mFilename);
            reader = new BufferedReader(new InputStreamReader(in));
            donations = new Gson().fromJson(reader.readLine(), objType);

            for(Donation d : donations)
                totalDonated += d.amount;
        }
        catch (FileNotFoundException e)
        {
            // we will ignore this one, since it happens when we start fresh
        }
        finally
        {
            if (reader != null)
                reader.close();
        }
        return donations;
    }

    public int getTotalDonated()
    {
        return totalDonated;
    }
}
